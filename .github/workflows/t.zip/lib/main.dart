import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'moris_flow_controller.dart';

void main() {
  runApp(const MorisFlowApp());
}

class MorisFlowApp extends StatelessWidget {
  const MorisFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    const background = Color(0xFF050505);
    const accent = Color(0xFF00FFFF);

    return ChangeNotifierProvider(
      create: (_) => MorisFlowController(),
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MorisFlow',
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: background,
          colorScheme: const ColorScheme.dark(
            primary: accent,
            secondary: accent,
          ),
          textTheme: ThemeData.dark().textTheme.apply(
                fontFamily: 'Segoe UI',
                bodyColor: Colors.white70,
                displayColor: Colors.white,
              ),
        ),
        home: const MorisFlowDashboard(),
      ),
    );
  }
}

class MorisFlowDashboard extends StatelessWidget {
  const MorisFlowDashboard({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl = context.watch<MorisFlowController>();
    const accent = Color(0xFF00FFFF);

    return Scaffold(
      body: Row(
        children: [
          const _Sidebar(),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _TopBar(statusText: ctrl.statusText),
                  const SizedBox(height: 24),
                  Expanded(
                    child: Row(
                      children: const [
                        Expanded(flex: 3, child: _DiagramPanel()),
                        SizedBox(width: 24),
                        Expanded(flex: 2, child: _ServerBrowserPanel()),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  _BottomActionBar(controller: ctrl),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  const _Sidebar();

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Container(
      width: 72,
      color: const Color(0xFF050505),
      child: Column(
        children: [
          const SizedBox(height: 24),
          Text(
            'MF',
            style: TextStyle(
              color: accent,
              fontWeight: FontWeight.bold,
              fontSize: 18,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 32),
          _SidebarIcon(
            icon: Icons.home_rounded,
            selected: true,
          ),
          _SidebarIcon(icon: Icons.games_rounded),
          _SidebarIcon(icon: Icons.settings_rounded),
          const Spacer(),
          _SidebarIcon(
            icon: Icons.person_rounded,
            small: true,
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _SidebarIcon extends StatelessWidget {
  final IconData icon;
  final bool selected;
  final bool small;

  const _SidebarIcon({
    required this.icon,
    this.selected = false,
    this.small = false,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          color: selected ? accent.withOpacity(0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        padding: const EdgeInsets.all(10),
        child: Icon(
          icon,
          size: small ? 18 : 22,
          color: selected ? accent : Colors.white54,
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final String statusText;

  const _TopBar({required this.statusText});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Row(
      children: [
        const Text(
          'MorisFlow',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: accent.withOpacity(0.6), width: 0.5),
          ),
          child: Text(
            statusText,
            style: TextStyle(
              fontSize: 11,
              color: statusText == 'TUNNEL ACTIVE' ? accent : Colors.white70,
              letterSpacing: 1.1,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
        const Spacer(),
        Text(
          'Disconnected',
          style: TextStyle(color: Colors.white54, fontSize: 12),
        ),
      ],
    );
  }
}

class _DiagramPanel extends StatelessWidget {
  const _DiagramPanel();

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    final ctrl = context.watch<MorisFlowController>();

    return _GlassPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Text(
                'Routes',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(width: 16),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.03),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: const Text(
                  'Diagram',
                  style: TextStyle(fontSize: 11, color: Colors.white70),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _NodeCircle(
                  label: 'PORT LOUIS, MU',
                  subtitle: 'Origin',
                  value: ctrl.latencyMs,
                ),
                _RouteArrow(active: ctrl.isActive),
                _NodeCard(
                  title: 'Doha-02',
                  subtitle: 'Doha, QA',
                  value: '0ms',
                  active: ctrl.isActive,
                ),
                _RouteArrow(active: ctrl.isActive),
                _NodeCircle(
                  label: 'GAME',
                  subtitle: 'Fortnite',
                  value: '',
                  icon: Icons.sports_esports_rounded,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NodeCircle extends StatelessWidget {
  final String label;
  final String subtitle;
  final String value;
  final IconData? icon;

  const _NodeCircle({
    required this.label,
    required this.subtitle,
    required this.value,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 72,
          height: 72,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: accent.withOpacity(0.7), width: 1),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.25),
                blurRadius: 24,
                spreadRadius: 4,
              ),
            ],
            color: Colors.white.withOpacity(0.02),
          ),
          child: Center(
            child: icon != null
                ? Icon(icon, color: accent)
                : Text(
                    value.isEmpty ? 'MU' : value,
                    style: const TextStyle(
                      color: accent,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            fontSize: 11,
            color: Colors.white70,
          ),
        ),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 10,
            color: Colors.white38,
          ),
        ),
      ],
    );
  }
}

class _NodeCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final String value;
  final bool active;

  const _NodeCard({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: active ? accent : Colors.white12,
          width: 0.8,
        ),
        color: Colors.white.withOpacity(0.03),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: const TextStyle(
              color: Colors.white54,
              fontSize: 11,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: const TextStyle(
              color: accent,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
        ],
      ),
    );
  }
}

class _RouteArrow extends StatelessWidget {
  final bool active;

  const _RouteArrow({required this.active});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Expanded(
      child: Container(
        height: 2,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Colors.white10,
              active ? accent : Colors.white24,
              Colors.white10,
            ],
          ),
        ),
      ),
    );
  }
}

class _ServerBrowserPanel extends StatelessWidget {
  const _ServerBrowserPanel();

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    final ctrl = context.watch<MorisFlowController>();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: const [
            Text(
              'Server Browser',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Expanded(
          child: _GlassPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: 'Search location…',
                    hintStyle:
                        const TextStyle(color: Colors.white38, fontSize: 12),
                    prefixIcon: const Icon(Icons.search, size: 18),
                    filled: true,
                    fillColor: Colors.white.withOpacity(0.03),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(999),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  style: const TextStyle(fontSize: 12),
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: ListView(
                    children: [
                      _ServerListSection(
                        title: 'Middle East',
                        children: [
                          _ServerRow(
                            name: 'Doha 02',
                            location: 'Doha',
                            ping: ctrl.latencyMs,
                            active: ctrl.isActive,
                            selectable: true,
                          ),
                          _ServerRow(
                            name: 'Dubai 01',
                            location: 'Dubai',
                            ping: '112ms',
                            disabled: true,
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const _ServerListSection(
                        title: 'Europe',
                        children: [
                          _ServerRow(
                            name: 'Frankfurt 01',
                            location: 'Germany',
                            disabled: true,
                            comingSoon: true,
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      const _ServerListSection(
                        title: 'Asia-Pacific',
                        children: [
                          _ServerRow(
                            name: 'Singapore 01',
                            location: 'Singapore',
                            disabled: true,
                            comingSoon: true,
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Align(
          alignment: Alignment.centerRight,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                'ESTIMATED LATENCY',
                style: TextStyle(
                  color: Colors.white54,
                  fontSize: 10,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(999),
                  color: Colors.white.withOpacity(0.05),
                  border: Border.all(color: accent.withOpacity(0.5), width: 0.5),
                ),
                child: Text(
                  ctrl.latencyMs == '—' ? '—' : ctrl.latencyMs,
                  style: const TextStyle(
                    color: accent,
                    fontWeight: FontWeight.bold,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ServerListSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _ServerListSection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            color: Colors.white60,
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 6),
        ...children,
      ],
    );
  }
}

class _ServerRow extends StatelessWidget {
  final String name;
  final String location;
  final String? ping;
  final bool disabled;
  final bool active;
  final bool comingSoon;
  final bool selectable;

  const _ServerRow({
    required this.name,
    required this.location,
    this.ping,
    this.disabled = false,
    this.active = false,
    this.comingSoon = false,
    this.selectable = false,
  });

  @override
  Widget build(BuildContext context) {
    final textColor =
        disabled ? Colors.white30 : (active ? Colors.white : Colors.white70);
    const accent = Color(0xFF00FFFF);

    return Opacity(
      opacity: disabled ? 0.5 : 1,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 2),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: active ? Colors.white.withOpacity(0.06) : Colors.transparent,
        ),
        child: Row(
          children: [
            Icon(
              Icons.dns_rounded,
              size: 18,
              color: textColor,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    name,
                    style: TextStyle(
                      color: textColor,
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  Text(
                    location,
                    style: const TextStyle(
                      color: Colors.white38,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
            if (ping != null && ping!.isNotEmpty && !comingSoon)
              Text(
                ping!,
                style: const TextStyle(
                  color: accent,
                  fontSize: 11,
                ),
              ),
            const SizedBox(width: 8),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(999),
                border: Border.all(
                  color: comingSoon ? Colors.white24 : accent.withOpacity(0.6),
                  width: 0.5,
                ),
                color: comingSoon
                    ? Colors.white.withOpacity(0.02)
                    : accent.withOpacity(0.1),
              ),
              child: Text(
                comingSoon
                    ? 'COMING SOON'
                    : (active ? 'ACTIVE' : (selectable ? 'SELECT' : '')),
                style: TextStyle(
                  color: comingSoon ? Colors.white60 : Colors.white,
                  fontSize: 9,
                  letterSpacing: 1.1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomActionBar extends StatelessWidget {
  final MorisFlowController controller;

  const _BottomActionBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return Row(
      children: [
        Expanded(
          child: _GlassPanel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Doha 02 – Fortnite Route',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Optimized path from Mauritius → Doha for gaming traffic only.',
                  style: const TextStyle(
                    color: Colors.white60,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 24),
        SizedBox(
          height: 56,
          child: ElevatedButton(
            onPressed: controller.isBusy
                ? null
                : () => context.read<MorisFlowController>().activateMorisFlow(),
            style: ElevatedButton.styleFrom(
              backgroundColor: accent.withOpacity(0.12),
              foregroundColor: Colors.white,
              side: const BorderSide(color: accent, width: 0.8),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(999),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 32),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (controller.isBusy)
                  const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: Colors.white,
                    ),
                  )
                else
                  const Icon(Icons.flash_on),
                const SizedBox(width: 8),
                const Text(
                  'ACTIVATE MORIS FLOW',
                  style: TextStyle(
                    letterSpacing: 1.4,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _GlassPanel extends StatelessWidget {
  final Widget child;

  const _GlassPanel({required this.child});

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF00FFFF);
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.04),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: accent.withOpacity(0.4), width: 0.5),
          ),
          child: child,
        ),
      ),
    );
  }
}

