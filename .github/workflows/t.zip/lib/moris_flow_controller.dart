import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:wireguard_flutter/wireguard_flutter.dart';

enum MorisFlowStatus {
  idle,
  activating,
  active,
  error,
}

class MorisFlowController extends ChangeNotifier {
  final WireguardFlutter _wg = WireguardFlutter();
  final DeviceInfoPlugin _deviceInfo = DeviceInfoPlugin();
  final http.Client _http = http.Client();

  MorisFlowStatus status = MorisFlowStatus.idle;
  String statusText = 'DISCONNECTED';
  String latencyMs = '—';
  String? errorMessage;

  bool get isBusy => status == MorisFlowStatus.activating;
  bool get isActive => status == MorisFlowStatus.active;

  Future<void> activateMorisFlow() async {
    if (isBusy) return;

    status = MorisFlowStatus.activating;
    statusText = 'CONNECTING…';
    errorMessage = null;
    notifyListeners();

    try {
      // 1. Generate local Curve25519 key pair
      final keyPair = await _wg.generateKeyPair();
      final privateKey = keyPair.privateKey;
      final publicKey = keyPair.publicKey;

      debugPrint('=== MORIS FLOW PUBLIC KEY ===');
      debugPrint(publicKey);
      debugPrint('==============================');

      // 2. Retrieve motherboard-style HWID (not yet sent anywhere)
      final hwid = await _getHardwareId();
      debugPrint('HWID: $hwid');

      // 3. Build WireGuard config in-memory with split tunneling
      const localAddress = '10.0.0.2/32';
      const allowedIps = [
        '15.185.0.0/16',
        '15.184.0.0/16',
        '52.95.0.0/12',
        '10.0.0.0/24',
      ];

      final config = [
        '[Interface]',
        'PrivateKey = $privateKey',
        'Address = $localAddress',
        'MTU = 1280',
        '',
        '[Peer]',
        'PublicKey = hkXi/PmLJIhkkJ9fWEXOAawPLpHAapgJuyGgko3Q5Ug=',
        'Endpoint = 34.18.33.234:51820',
        'PersistentKeepalive = 25',
        'AllowedIPs = ${allowedIps.join(', ')}',
      ].join('\n');

      await _wg.start(config: config);

      status = MorisFlowStatus.active;
      statusText = 'TUNNEL ACTIVE';
      latencyMs = '90ms';
      notifyListeners();
    } catch (e) {
      status = MorisFlowStatus.error;
      statusText = 'ERROR';
      errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> deactivateMorisFlow() async {
    try {
      await _wg.stop();
    } catch (_) {}
    status = MorisFlowStatus.idle;
    statusText = 'DISCONNECTED';
    latencyMs = '—';
    notifyListeners();
  }

  Future<String> _getHardwareId() async {
    try {
      final result = await Process.run(
        'wmic',
        ['baseboard', 'get', 'serialnumber'],
        runInShell: true,
      );
      if (result.exitCode == 0 && result.stdout is String) {
        final lines = (result.stdout as String)
            .split('\n')
            .map((l) => l.trim())
            .where((l) => l.isNotEmpty && !l.toLowerCase().contains('serialnumber'))
            .toList();
        if (lines.isNotEmpty) {
          return lines.first;
        }
      }
    } catch (_) {}

    final win = await _deviceInfo.windowsInfo;
    final raw = [
      win.computerName,
      win.productName,
      win.systemMemoryInMegabytes.toString(),
    ].join('|');
    return base64Url.encode(utf8.encode(raw));
  }
}

